*Scatter
clear
import delimited "C:\Users\cascr\OneDrive\Master HTI\OneDrive - TU Eindhoven\Master\MTP\Code\Master Cas\experiment_logs\71A_72A\rms_log.csv", clear

gen str30 timestamp_clean = subinstr(timestamp, "T", " ", .)
gen double time_ms = clock(timestamp_clean, "YMDhms#")
format time_ms %tc

gen time_sec = (time_ms - time_ms[1]) / 1000

keep if time_sec >= 0 & time_sec <= 1000

destring left_rms right_rms left_threshold right_threshold, replace force

twoway ///
    (scatter left_rms time_sec, ///
        mcolor(orange) msymbol(circle) msize(tiny)) ///
    (scatter right_rms time_sec, ///
        mcolor(purple) msymbol(circle) msize(tiny)), ///
    legend(order(1 "Participant 8" 2 "Participant 9")) ///
    xtitle("Elapsed Time (in seconds)") ///
    ytitle("Audio Level") ///
    title("Audio Levels vs Elapsed Time") ///
    graphregion(color(white)) ///
    plotregion(color(white))
	
*Timeline RMS
clear
global folder "C:\Users\cascr\OneDrive\Master HTI\OneDrive - TU Eindhoven\Master\MTP\Code\Master Cas\experiment_logs\99A_100A"

tempfile rms_base eye_events


import delimited "$folder\rms_log.csv", clear

gen str30 timestamp_clean = subinstr(timestamp, "T", " ", .)
gen double time_ms = clock(timestamp_clean, "YMDhms#")
format time_ms %tc

summ time_ms, meanonly
local t0 = r(min)

gen time_sec = (time_ms - `t0') / 1000

destring left_rms right_rms left_threshold right_threshold, replace force

keep if time_sec >= 200 & time_sec <= 400
save `rms_base', replace

*Eye contact
import delimited "$folder\timeline_log.csv", clear

gen str30 timestamp_clean = subinstr(timestamp, "T", " ", .)
gen double time_ms = clock(timestamp_clean, "YMDhms#")
format time_ms %tc

gen time_sec = (time_ms - `t0') / 1000

drop if eye_contact == 1 & pitch >= 20
drop if eye_contact == 1 & pitch <= -20

gen trigger_candidate = eye_contact == 1 & silence_duration >= 1

sort time_sec
gen previous_candidate = trigger_candidate[_n-1]

keep if trigger_candidate == 1 & previous_candidate != 1
keep if time_sec >= 200 & time_sec <= 400

gen ymin = 0
gen ymax = 10

keep time_sec ymin ymax
save `eye_events', replace

*Graph
use `rms_base', clear
append using `eye_events'

twoway ///
    (line left_rms time_sec, lcolor(orange) lwidth(thin)) ///
    (line right_rms time_sec, lcolor(purple) lwidth(thin)) ///
    (rspike ymin ymax time_sec if !missing(ymin), ///
        vertical lcolor(red) lpattern(dash) lwidth(thin)), ///
    legend(order(1 "P37 audio level" 2 "P38 audio level" 3 "Eye contact") position(1) ring(0)) ///) ///
    xtitle("Elapsed time in seconds") ///
    ytitle("Audio RMS") ///
    title("Audio levels together with eye contact") ///
    graphregion(color(white)) ///
    plotregion(color(white))
	
graph export "C:\Users\cascr\OneDrive\Master HTI\OneDrive - TU Eindhoven\Master\MTP\analysis\RMStimeline.png", replace width(2000)

clear
global folder "C:\Users\cascr\OneDrive\Master HTI\OneDrive - TU Eindhoven\Master\MTP\Code\Master Cas\experiment_logs\99A_100A"

tempfile rms_base eye_events

*RMS
import delimited "$folder\rms_log.csv", clear

gen str30 timestamp_clean = subinstr(timestamp, "T", " ", .)
gen double time_ms = clock(timestamp_clean, "YMDhms#")
format time_ms %tc

summ time_ms, meanonly
local t0 = r(min)

gen time_sec = (time_ms - `t0') / 1000

destring left_rms right_rms left_threshold right_threshold, replace force

keep if time_sec >= 200 & time_sec <= 400

replace left_rms = . if left_rms > 1
replace right_rms = . if right_rms > 1

save `rms_base', replace

*eye contact
import delimited "$folder\timeline_log.csv", clear

gen str30 timestamp_clean = subinstr(timestamp, "T", " ", .)
gen double time_ms = clock(timestamp_clean, "YMDhms#")
format time_ms %tc

gen time_sec = (time_ms - `t0') / 1000

drop if eye_contact == 1 & pitch >= 20
drop if eye_contact == 1 & pitch <= -20

gen trigger_candidate = eye_contact == 1 & silence_duration >= 1

sort time_sec
gen previous_candidate = trigger_candidate[_n-1]

keep if trigger_candidate == 1 & previous_candidate != 1
keep if time_sec >= 200 & time_sec <= 400

gen ymin = 0
gen ymax = 1

keep time_sec ymin ymax
save `eye_events', replace


*Graph
use `rms_base', clear
append using `eye_events'

twoway ///
    (line left_rms time_sec, lcolor(blue) lwidth(thin)) ///
    (line right_rms time_sec, lcolor(red) lwidth(thin)) ///
    (rspike ymin ymax time_sec if !missing(ymin), ///
        vertical lcolor(grey) lpattern(dash) lwidth(thin)), ///
    legend(order(1 "P37 audio level" 2 "P38 audio level" 3 "Eye contact") ///
        position(3) ring(1)) ///
    xtitle("Duration in seconds") ///
    ytitle("Audio RMS") ///
    title("Audio levels together with eye contact during a conversation") ///
    yscale(range(0 1) noextend) ///
    ylabel(0(0.2)1) ///
    graphregion(color(white)) ///
    plotregion(color(white))

graph export "C:\Users\cascr\OneDrive\Master HTI\OneDrive - TU Eindhoven\Master\MTP\analysis\RMStimelinev1.png", ///
    replace width(2000)
    plotregion(color(white))