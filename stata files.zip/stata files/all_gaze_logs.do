clear all
set more off
local root "C:/Users/cascr/OneDrive/Master HTI/OneDrive - TU Eindhoven/Master/MTP/Code/Master Cas/experiment_logs"

tempfile gaze_master
save `gaze_master', emptyok replace

local folders : dir "`root'" dirs "*"

foreach folder of local folders {

    if strpos("`folder'", "_") > 0 & strpos("`folder'", "__") == 0 {

        local file "`root'/`folder'/gaze_log.csv"
        capture confirm file "`file'"

        if !_rc {
            di "Importing gaze log: `folder'"

            import delimited "`file'", clear

            gen session = "`folder'"

            split session, parse("_") gen(pid)

            gen condition = upper(substr(pid1, -1, 1))

            gen left_participant  = substr(pid1, 1, length(pid1)-1)
            gen right_participant = substr(pid2, 1, length(pid2)-1)

            destring left_participant, gen(left_id) force
            destring right_participant, gen(right_id) force

            gen pair_id = string(left_id) + "_" + string(right_id)

            gen gaze_model = ""
            replace gaze_model = "Broad"  if left_id >= 51 & left_id <= 79
            replace gaze_model = "Direct" if left_id >= 81 & left_id <= 102

            drop pid1 pid2 left_participant right_participant

            append using `gaze_master'
            save `gaze_master', replace
        }
    }
}

use `gaze_master', clear

capture drop timestamp_clean_gaze timestamp_clean time_ms

gen str30 timestamp_clean_gaze = subinstr(timestamp, "T", " ", .)
gen double time_ms = clock(timestamp_clean_gaze, "YMD hms#")
format time_ms %tc

drop if missing(left_id) | missing(right_id)

drop if inlist(left_id, 93, 75, 51) | ///
        inlist(right_id, 94, 76, 52)

drop if missing(gaze_model)
drop if missing(condition)

drop if robot_eye_contact == 1 & pitch > 20
drop if robot_eye_contact == 1 & pitch < -20

drop if human_directed_gaze == 1 & pitch > 20
drop if human_directed_gaze == 1 & pitch < -20

drop if missing(yaw)
drop if missing(pitch)

drop if eye_contact_duration_individual > 20 & ///
        !missing(eye_contact_duration_individual)

encode condition, gen(condition_num)
encode pair_id, gen(pair_num)
encode gaze_model, gen(gaze_model_num)

* TIMESTAMP 

gen time = clock(timestamp, "YMD#hms#")
format time %tc

egen first_time = min(time), by(pair_id condition)

gen elapsed_sec = (time - first_time) / 1000
gen elapsed_min = elapsed_sec / 60

save "C:/Users/cascr/OneDrive/Master HTI/OneDrive - TU Eindhoven/Master/MTP/analysis/all_gaze_logs.dta", replace

describe
summarize

tab condition
tab pair_id condition
tab gaze_model condition

tabstat yaw pitch robot_eye_contact human_directed_gaze, ///
    by(gaze_model) ///
    stats(n mean sd median min max)

tabstat yaw pitch robot_eye_contact human_directed_gaze, ///
    by(condition) ///
    stats(n mean sd median min max)

tab direction gaze_model
tab direction condition

tabstat robot_eye_contact human_directed_gaze, ///
    by(gaze_model) ///
    stats(n mean sd)

tabstat robot_eye_contact human_directed_gaze, ///
    by(condition) ///
    stats(n mean sd)


* EYE CONTACT DURATION

summarize eye_contact_duration_individual, detail
sum eye_contact_duration_individual

histogram eye_contact_duration_individual, ///
    percent ///
    title("Eye Contact Duration Distribution") ///
    xtitle("Eye contact duration (s)") ///
    ytitle("Relative Frequency (%)")


* FIGURES
gen abs_yaw = abs(yaw)

twoway ///
(histogram abs_yaw if gaze_model=="Broad", ///
    percent width(2) start(0) color(navy%40) lcolor(navy)) ///
(histogram abs_yaw if gaze_model=="Direct", ///
    percent width(2) start(0) color(maroon%40) lcolor(maroon)), ///
legend(order(1 "Extended Gaze Detection" 2 "Direct Gaze Detection")) ///
title("Absolute Yaw Distribution by Gaze Detection Model") ///
xtitle("Absolute yaw angle (degrees)") ///
ytitle("Frequency (%)")
	
graph export "histyaw.png", replace width(2000)

twoway ///
(histogram abs_yaw if condition=="A", ///
    percent width(2) start(0) color(navy%40) lcolor(navy)) ///
(histogram abs_yaw if condition=="B", ///
    percent width(2) start(0) color(maroon%40) lcolor(maroon)), ///
legend(order(1 "Static Gaze Aversion" 2 "Timed Gaze Aversion")) ///
title("Absolute Yaw Distribution by Robot's Gaze Behavior") ///
xtitle("Absolute yaw angle (degrees)") ///
ytitle("Frequency (%)")

graph export "histyawcond.png", replace width(2000)

histogram pitch, ///
    percent ///
    normal ///
    title("Pitch Distribution") ///
    xtitle("Pitch angle (degrees)") ///
    ytitle("Relative Frequency (%)")

graph box yaw, over(gaze_model) ///
    title("Yaw Angle by Gaze Model") ///
    ytitle("Yaw angle (degrees)")

graph box yaw, over(condition) ///
    title("Yaw Angle by A/B Condition") ///
    ytitle("Yaw angle (degrees)")

histogram eye_contact_duration_individual
graph export "eyecontactdur.png", replace width(2000)

* CREATE SESSION-LEVEL GAZE DATA

preserve

collapse ///
    (mean) mean_yaw = yaw ///
    (mean) mean_abs_yaw = abs_yaw ///
    (mean) mean_pitch = pitch ///
    (mean) eye_contact_rate = robot_eye_contact ///
    (mean) human_gaze_rate = human_directed_gaze ///
    (count) n_gaze_frames = robot_eye_contact, ///
    by(pair_id condition gaze_model)

encode condition, gen(condition_num)
encode pair_id, gen(pair_num)
encode gaze_model, gen(gaze_model_num)

save "C:/Users/cascr/OneDrive/Master HTI/OneDrive - TU Eindhoven/Master/MTP/analysis/gaze_descriptives_sessionlevel.dta", replace

tabstat mean_yaw mean_abs_yaw mean_pitch eye_contact_rate human_gaze_rate n_gaze_frames, ///
    by(gaze_model) ///
    stats(n mean sd median min max)

tabstat mean_yaw mean_abs_yaw mean_pitch eye_contact_rate human_gaze_rate n_gaze_frames, ///
    by(condition) ///
    stats(n mean sd median min max)

*EYE CONTACT RATE

mixed eye_contact_rate i.gaze_model_num##i.condition_num || pair_num:
capture drop fitted_eye resid_eye re_eye tag_pair
predict fitted_eye, fitted
predict resid_eye, residuals
predict re_eye, reffects
egen tag_pair = tag(pair_num)

histogram resid_eye, normal ///

qnorm resid_eye, ///

scatter resid_eye fitted_eye, ///
    yline(0) ///

qnorm re_eye if tag_pair == 1, ///

swilk resid_eye
swilk re_eye if tag_pair == 1

* HUMAN-DIRECTED GAZE RATE

mixed human_gaze_rate i.gaze_model_num##i.condition_num || pair_num:

capture drop fitted_eye resid_eye re_eye tag_pair
predict fitted_eye, fitted
predict resid_eye, residuals
predict re_eye, reffects
egen tag_pair = tag(pair_num)

histogram resid_eye, normal ///

qnorm resid_eye, ///

scatter resid_eye fitted_eye, ///
    yline(0) ///

qnorm re_eye if tag_pair == 1, ///

swilk resid_eye
swilk re_eye if tag_pair == 1


* MEAN ABSOLUTE YAW

mixed mean_abs_yaw i.gaze_model_num##i.condition_num || pair_num:

capture drop fitted_eye resid_eye re_eye tag_pair
predict fitted_eye, fitted
predict resid_eye, residuals
predict re_eye, reffects
egen tag_pair = tag(pair_num)

histogram resid_eye, normal ///

qnorm resid_eye, ///

scatter resid_eye fitted_eye, ///
    yline(0) ///

qnorm re_eye if tag_pair == 1, ///

swilk resid_eye
swilk re_eye if tag_pair == 1


restore
