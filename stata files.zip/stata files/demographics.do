clear 
set more off

import delimited ///
"C:\Users\cascr\OneDrive\Master HTI\OneDrive - TU Eindhoven\Master\MTP\analysis\questionnaire_data\Pre-experiment questionnaire.csv", ///

*Inspection
describe
codebook

rename whatisyourage age
rename whatisyourgender gender
rename whatisyourparticipantid id
rename doyouhaveanypriorexperienceswith experience_robots
rename v7 experience_interface
rename v8 height

*Drop ids that went wrong
drop if id == 93
drop if id == 94
drop if id == 51
drop if id == 52
drop if id == 75
drop if id == 76
drop if missing(id)

*Rename id
tab id
replace id = 99 if id == 2090937
replace id = 100 if id == 2246473

*Fix height (replace extremes with missing)
tab height
gen height_new = regexs(1) if regexm(height, "([0-9]+\.?[0-9]*)")
destring height_new, replace
replace height_new = . if inlist(height_new, 25, 30, 31, 32, 33, 132)
tab height_new
sum

*Experience
gen experience_interface_binary = .
replace experience_interface_binary = 0 if ///
strpos(lower(experience_interface), "no") | ///
strpos(lower(experience_interface), "a little") | ///
strpos(lower(experience_interface), "not really") | ///
strpos(lower(experience_interface), "not much") | ///
strpos(lower(experience_interface), "once or twice") | ///
strpos(lower(experience_interface), "rarely") | ///
strpos(lower(experience_interface), "never used it regularly") | ///
strpos(lower(experience_interface), "few times")
replace experience_interface_binary = 1 if missing(experience_interface_binary)

label define exp_lbl 0 "No/Little experience" 1 "Experience"
label values experience_interface_binary exp_lbl
tab experience_interface_binary

gen experience_robots_binary = .
replace experience_robots_binary = 0 if ///
strpos(lower(experience_robots), "not really") | ///
strpos(lower(experience_robots), "barely") | ///
strpos(lower(experience_robots), "not a lot") | ///
strpos(lower(experience_robots), "no") | ///
strpos(lower(experience_robots), "barely") | ///
strpos(lower(experience_robots), "a bit")
replace experience_robots_binary = 1 if missing(experience_robots_binary)

label define exp_r 0 "No/Little experience" 1 "Experience"
label values experience_robots_binary exp_r
tab experience_robots_binary

*Demo
tabstat age height_new, ///
statistics(n mean sd min max) ///
columns(statistics)

* Mean and SD age
sum age

* Gender distribution
tab gender

* Mean and SD torso-to-eye height
sum height_new

* Prior robot experience
tab experience_robots_binary

* Prior speech interface experience
tab experience_interface_binary

*Precentages of robots interactions
gen mention_vacuum = strpos(lower(experience_robots), "vacuum") > 0 | ///
                     strpos(lower(experience_robots), "roomba") > 0

gen mention_service = strpos(lower(experience_robots), "service") > 0

gen mention_humanoid = strpos(lower(experience_robots), "humanoid") > 0

gen mention_experiment = strpos(lower(experience_robots), "experiment") > 0 | ///
                         strpos(lower(experience_robots), "research") > 0 | ///
                         strpos(lower(experience_robots), "hti") > 0

tab mention_vacuum
tab mention_service
tab mention_humanoid
tab mention_experiment

*Percentage interface experience

gen mention_siri = strpos(lower(experience_interface), "siri") > 0
gen mention_google = strpos(lower(experience_interface), "google") > 0
gen mention_alexa = strpos(lower(experience_interface), "alexa") > 0
gen mention_gemini = strpos(lower(experience_interface), "gemini") > 0
gen mention_chatgpt = strpos(lower(experience_interface), "chatgpt") > 0
gen mention_bixby = strpos(lower(experience_interface), "bixby") > 0

tab mention_siri
tab mention_google
tab mention_alexa
tab mention_gemini
tab mention_chatgpt
tab mention_bixby

generate experience = (experience_interface_binary == 1 | ///
                                experience_robots_binary == 1)
tab experience

save "C:\Users\cascr\OneDrive\Master HTI\OneDrive - TU Eindhoven\Master\MTP\analysis\questionnaire_data\pre_demographics_clean.dta", replace