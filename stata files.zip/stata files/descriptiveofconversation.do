clear
set more off

tempfile master
save `master', emptyok replace

local root "C:/Users/cascr/OneDrive/Master HTI/OneDrive - TU Eindhoven/Master/MTP/Code/Master Cas/experiment_logs"

local folders : dir "`root'" dirs "*"

foreach folder of local folders {

    if strpos("`folder'", "_") > 0 & strpos("`folder'", "__") == 0 {

        local currentfolder "`root'/`folder'"
        local summaryfiles : dir "`currentfolder'" files "summary_log*.csv"

        foreach f of local summaryfiles {

            di "Importing: `folder' / `f'"

            import delimited "`currentfolder'/`f'", clear

            gen session = "`folder'"
            gen summary_file = "`f'"

            append using `master'
            save `master', replace
        }
    }
}

use `master', clear

*Reshape
destring value, replace force

reshape wide value, i(session summary_file) j(metric) string

rename valueturn_count_human_human human_human_turns
rename valueturn_count_human_robot human_robot_turns
rename valueturn_count_robot_human robot_human_turns
rename valueturn_count_robot_robot robot_robot_turns

capture rename valuetotal_eye_contact_time total_eye_contact_time

gen total_turns = ///
human_human_turns + ///
human_robot_turns + ///
robot_human_turns + ///
robot_robot_turns

* Robot takes the turn after human
gen robot_turns = human_robot_turns

*Clean data
split session, parse("_") gen(pid)

gen left_participant  = substr(pid1, 1, length(pid1)-1)
gen right_participant = substr(pid2, 1, length(pid2)-1)

destring left_participant, gen(left_id)
destring right_participant, gen(right_id)

gen condition = upper(substr(pid1, -1, 1))

gen pair_id = string(left_id) + "_" + string(right_id)

gen gaze_model = ""
replace gaze_model = "Broad"  if left_id >= 51 & left_id <= 79
replace gaze_model = "Direct" if left_id >= 81 & left_id <= 102

drop pid1 pid2 left_participant right_participant

drop if inlist(left_id, 93, 94, 51, 52, 75, 76) | ///
        inlist(right_id, 93, 94, 51, 52, 75, 76)

* Merge
merge 1:1 session using "C:\Users\cascr\OneDrive\Master HTI\OneDrive - TU Eindhoven\Master\MTP\analysis\speech_descriptives_sessionlevel_clean.dta", ///
keepusing(dialogue_duration_sec dialogue_duration_min)

drop if _merge == 2
drop _merge

* Robot turns per 1-minute dyad
gen robot_turns_1min = robot_turns / (dialogue_duration_sec / 60)

* Overal descriptives
tabstat total_turns dialogue_duration_sec robot_turns robot_turns_1min, ///
statistics(n mean sd min max) ///
columns(statistics)

tabstat total_turns, ///
by(condition) ///
statistics(n mean sd)

tabstat dialogue_duration_sec robot_turns robot_turns_1min, ///
by(condition) ///
statistics(mean sd)

tabstat total_turns, ///
by(gaze_model) ///
statistics(n mean sd)

tabstat dialogue_duration_sec robot_turns robot_turns_1min, ///
by(gaze_model) ///
statistics(mean sd)

sort gaze_model condition

by gaze_model condition: tabstat total_turns dialogue_duration_sec robot_turns robot_turns_1min, ///
statistics(n mean sd min max)

save "summarylog_with_duration_clean.dta", replace