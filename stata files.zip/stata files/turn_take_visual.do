clear
set more off
import delimited "C:\Users\cascr\OneDrive\Master HTI\OneDrive - TU Eindhoven\Master\MTP\Code\Master Cas\experiment_logs\97B_98B\timeline_log.csv", clear

* Convert timestamp
gen str30 timestamp_clean = subinstr(timestamp, "T", " ", .)
gen double time_ms = clock(timestamp_clean, "YMD hms#")
format time_ms %tc

* Relative time in seconds
gen time_sec = (time_ms - time_ms[1]) / 1000

count if speaker=="l" & yaw<-25
count if speaker=="r" & yaw>25
sum yaw

* Remove inconsistent yaw directions
drop if speaker == "r" & yaw > 25
drop if speaker == "l" & yaw < -25

* Make yaw direction consistent
gen yaw_plot = yaw

drop if eye_contact == 1 & pitch >= 20
drop if eye_contact == 1 & pitch <= -20

* Remove missing values
drop if missing(yaw_plot) | missing(time_sec)

* Graph raw yaw values
twoway ///
    (scatter yaw_plot time_sec if speaker == "l", ///
        msize(vsmall) ///
        mcolor(blue%60)) ///
    (scatter yaw_plot time_sec if speaker == "r", ///
        msize(vsmall) ///
        mcolor(red%60)) ///
    (function y=25, range(0 1600) ///
        lpattern(dash) ///
        lcolor(black)) ///
    (function y=-25, range(0 1600) ///
        lpattern(dash) ///
        lcolor(black)), ///
    xtitle("Time (seconds)") ///
    ytitle("Yaw angle (degrees)") ///
    xlabel(0(200)1600) ///
    ylabel(-75(25)75) ///
    xscale(range(0 1600)) ///
    yscale(range(-75 75)) ///
    legend(order(1 "Left participant (P33)" 2 "Right participant (P34)" 3 "+25 threshold" 4 "-25 threshold"))
	
graph export "yawangle_broad.png", replace width(2000)

clear
import delimited "C:\Users\cascr\OneDrive\Master HTI\OneDrive - TU Eindhoven\Master\MTP\Code\Master Cas\experiment_logs\67A_68A\timeline_log.csv", clear

* Convert timestamp
gen str30 timestamp_clean = subinstr(timestamp, "T", " ", .)
gen double time_ms = clock(timestamp_clean, "YMD hms#")
format time_ms %tc

* Relative time in seconds
gen time_sec = (time_ms - time_ms[1]) / 1000

* Remove inconsistent yaw directions
drop if speaker == "r" & yaw > 25
drop if speaker == "l" & yaw < -25
* Make yaw direction consistent
gen yaw_plot = yaw
replace yaw_plot = abs(yaw) if speaker == "l"
replace yaw_plot = -abs(yaw) if speaker == "r"

drop if eye_contact == 1 & pitch >= 20
drop if eye_contact == 1 & pitch <= -20

* Remove missing values
drop if missing(yaw_plot) | missing(time_sec)

* Graph raw yaw values - Direct gaze model
twoway ///
    (scatter yaw_plot time_sec if speaker == "l", ///
        msize(vsmall) ///
        mcolor(blue%60)) ///
    (scatter yaw_plot time_sec if speaker == "r", ///
        msize(vsmall) ///
        mcolor(red%60)) ///
    (function y=10, range(0 1200) ///
        lpattern(dash) ///
        lcolor(black)) ///
    (function y=-10, range(0 1200) ///
        lpattern(dash) ///
        lcolor(black)), ///
    xtitle("Time (seconds)") ///
    ytitle("Yaw angle (degrees)") ///
    xlabel(0(200)1200) ///
    ylabel(-75(25)75) ///
	xscale(range(0 1200)) ///
    yscale(range(-75 75)) ///
    legend(order(1 "Left participant (P15)" 2 "Right participant (P16)" 3 "+10 threshold" 4 "-10 threshold"))

graph export "yawangle_direct.png", replace width(2000)

*TIMELINE GRAPH 
clear
set more off

local folder "C:\Users\cascr\OneDrive\Master HTI\OneDrive - TU Eindhoven\Master\MTP\Code\Master Cas\experiment_logs\99A_100A"

tempfile human_events robot_events overlap_events

import delimited "`folder'\speech_log.csv", clear

* Convert timestamps
gen str30 start_clean = subinstr(timestamp_start, "T", " ", .)
gen double start_ms = clock(start_clean, "YMD hms#")

gen str30 end_clean = subinstr(timestamp_end, "T", " ", .)
gen double end_ms = clock(end_clean, "YMD hms#")

format start_ms end_ms %tc

tab event_type
tab speaker
tab event_type speaker
tab interruption_type

egen first_time = rowmin(start_ms end_ms)
summarize first_time if !missing(first_time)
local t0 = r(min)

* EYE CONTACT

tempfile speech_base eye_events
save `speech_base', replace

import delimited "`folder'\timeline_log.csv", clear

gen str30 timestamp_clean = subinstr(timestamp, "T", " ", .)
gen double time_ms = clock(timestamp_clean, "YMD hms#")
format time_ms %tc

gen time = (time_ms - `t0') / 1000

drop if speaker == "r" & yaw > 25
drop if speaker == "l" & yaw < -25

drop if eye_contact == 1 & pitch >= 20
drop if eye_contact == 1 & pitch <= -20
drop if time < 0
drop if missing(time)

* Eye contact + silence condition
gen trigger_candidate = eye_contact == 1 & silence_duration >= 1

sort time

* Create episodes of continuous trigger_candidate == 1
gen new_episode = trigger_candidate == 1 & ///
    (trigger_candidate[_n-1] != 1 | _n == 1)

gen episode_id = sum(new_episode)

* Keep only candidate rows
keep if trigger_candidate == 1

* Duration of each continuous eye-contact trigger episode
bysort episode_id: egen episode_start = min(time)
bysort episode_id: egen episode_end   = max(time)

gen episode_duration = episode_end - episode_start

* Keep only episodes lasting at least 500 ms
keep if episode_duration >= 0.5

* Keep only the first frame of each valid episode
bysort episode_id (time): keep if _n == 1

gen ymin = 0.5
gen ymax = 4.5
gen event = "Eye contact trigger"

keep time ymin ymax event
save `eye_events', replace

use `speech_base', clear

* HUMAN SPEECH
preserve

keep if event_type == "human_turn"
keep if speaker == "l" | speaker == "r"

gen start = (start_ms - `t0') / 1000
gen end   = (end_ms - `t0') / 1000

gen y = .
replace y = 3 if speaker == "l"
replace y = 2 if speaker == "r"

gen event = ""
replace event = "Left speaking" if speaker == "l"
replace event = "Right speaking" if speaker == "r"

drop if missing(start) | missing(end) | missing(y)
drop if end <= start

keep start end y event
save `human_events', replace

restore

* ROBOT SPEECH
preserve

keep if event_type == "robot_turn_start" | event_type == "robot_turn_end"

gen double robot_time_start = start_ms if event_type == "robot_turn_start"
gen double robot_time_end   = end_ms   if event_type == "robot_turn_end"

tempfile robot_base robot_starts robot_ends
save `robot_base', replace

use `robot_base', clear
keep if event_type == "robot_turn_start"
keep if !missing(robot_time_start)
sort robot_time_start
gen pair = _n
rename robot_time_start robot_start
keep pair robot_start
save `robot_starts', replace

use `robot_base', clear
keep if event_type == "robot_turn_end"
keep if !missing(robot_time_end)
sort robot_time_end
gen pair = _n
rename robot_time_end robot_end
keep pair robot_end
save `robot_ends', replace

use `robot_starts', clear
merge 1:1 pair using `robot_ends', nogen

gen start = (robot_start - `t0') / 1000
gen end   = (robot_end   - `t0') / 1000

drop if missing(start) | missing(end)
drop if end <= start
drop if end - start > 40

gen y = 4
gen event = "Robot speaking"

keep start end y event
save `robot_events', replace

restore

*OVERLAP
preserve

keep if event_type == "overlap" | interruption_type != ""
drop if interruption_type == "robot_interrupts_human" ///
    & speaker == "robot" ///
    & turn_from == "robot"

gen start = (start_ms - `t0') / 1000
gen end   = (end_ms - `t0') / 1000

replace end = start + 0.5 if missing(end)

drop if missing(start) | missing(end)
drop if end <= start

gen y = 1
gen event = "Overlap"

gen overlap_left  = 0
gen overlap_right = 0
gen overlap_robot = 0

* Human-human overlap: both participants
replace overlap_left  = 1 if speaker == "b"
replace overlap_right = 1 if speaker == "b"

replace overlap_left  = 1 if interruption_type == "human_human_overlap"
replace overlap_right = 1 if interruption_type == "human_human_overlap"

* Robot interrupts one human: robot + previous speaker
replace overlap_robot = 1 if interruption_type == "robot_interrupts_human"

replace overlap_left  = 1 if interruption_type == "robot_interrupts_human" & turn_from == "l"
replace overlap_right = 1 if interruption_type == "robot_interrupts_human" & turn_from == "r"

replace overlap_left  = 1 if interruption_type == "robot_interrupts_human" & missing(turn_from) & speaker == "l"
replace overlap_right = 1 if interruption_type == "robot_interrupts_human" & missing(turn_from) & speaker == "r"

keep start end y event overlap_left overlap_right overlap_robot
save `overlap_events', replace

restore

* COMBINE 
use `human_events', clear
append using `robot_events'
append using `overlap_events'
append using `eye_events'

gen y_left_overlap = 3
gen y_right_overlap = 2
gen y_robot_overlap = 4

* Clean speech/overlap/robot rows
drop if event != "Eye contact trigger" & start < 0
drop if event != "Eye contact trigger" & end < 0
drop if event != "Eye contact trigger" & end <= start

* Clean eye-contact rows
drop if event == "Eye contact trigger" & time < 0
drop if event == "Eye contact trigger" & missing(time)

tab event
summarize start end

* GRAPH
twoway ///
    (rspike start end y if event == "Left speaking", ///
        horizontal lcolor(blue) lwidth(thick)) ///
    (rspike start end y if event == "Right speaking", ///
        horizontal lcolor(red) lwidth(thick)) ///
    (rspike start end y if event == "Robot speaking", ///
        horizontal lcolor(black) lwidth(thick)) ///
    (rspike start end y_left_overlap if event == "Overlap" & overlap_left == 1, ///
        horizontal lcolor(blue) lwidth(thick)) ///
    (rspike start end y_right_overlap if event == "Overlap" & overlap_right == 1, ///
        horizontal lcolor(red) lwidth(thick)) ///
    (rspike start end y_robot_overlap if event == "Overlap" & overlap_robot == 1, ///
        horizontal lcolor(black) lwidth(thick)) ///
    (scatter y start if event == "Overlap", ///
        mcolor(orange) msymbol(diamond) msize(small)) ///
    (rspike ymin ymax time if event == "Eye contact trigger", ///
        lcolor(gs10) lpattern(dash) lwidth(vthin)) ///
    , ///
    ylabel(1 "Overlap" ///
           2 "Right participant" ///
           3 "Left participant" ///
           4 "Robot", angle(0) labsize(small)) ///
    xlabel(0(200)1200, nogrid labsize(small)) ///
    yscale(range(0.5 4.5)) ///
    title("Timeline of an experiment session", size(medsmall)) ///
    xtitle("Time (seconds)", size(small)) ///
    ytitle("") ///
    legend(order(1 "Left speaking" ///
                 2 "Right speaking" ///
                 3 "Robot speaking" ///
                 7 "Overlap" ///
                 8 "Eye contact") ///
           rows(1) ///
           position(6) ///
           ring(0) ///
           size(small)) ///
    graphregion(color(white)) ///
    plotregion(color(white))

graph export "timelineexperiment.png", replace width(2000)
	
* IMPORT 

clear
set more off

tempfile timeline_master
save `timeline_master', emptyok replace

local root "C:/Users/cascr/OneDrive/Master HTI/OneDrive - TU Eindhoven/Master/MTP/Code/Master Cas/experiment_logs"

local folders : dir "`root'" dirs "*"

foreach folder of local folders {

    if strpos("`folder'", "_") > 0 & strpos("`folder'", "__") == 0 {

        local currentfolder "`root'/`folder'"
        local timelinefiles : dir "`currentfolder'" files "timeline_log*.csv"

        foreach f of local timelinefiles {

            di "Importing timeline: `folder' / `f'"

            import delimited "`currentfolder'/`f'", clear

            gen session = "`folder'"
            gen timeline_file = "`f'"

            append using `timeline_master'
            save `timeline_master', replace
        }
    }
}

use `timeline_master', clear

* EXTRACT PARTICIPANT ID

split session, parse("_") gen(pid)

gen left_participant  = substr(pid1, 1, length(pid1)-1)
gen right_participant = substr(pid2, 1, length(pid2)-1)

destring left_participant, gen(left_id)
destring right_participant, gen(right_id)

gen condition = upper(substr(pid1, -1, 1))

gen pair_id = string(left_id) + "_" + string(right_id)
encode pair_id, gen(pair_num)

gen gaze_model = ""
replace gaze_model = "Broad"  if left_id >= 51 & left_id <= 79
replace gaze_model = "Direct" if left_id >= 81 & left_id <= 102

drop pid1 pid2 left_participant right_participant

drop if inlist(left_id, 93, 75, 51) | ///
        inlist(right_id, 94, 76, 52)

gen str30 timestamp_clean = subinstr(timestamp, "T", " ", .)
gen double time_ms = clock(timestamp_clean, "YMD hms#")
format time_ms %tc

sort session time_ms

* YAW ANALYSIS
preserve

drop if missing(yaw)
drop if missing(pitch)

drop if eye_contact == 1 & pitch >= 20
drop if eye_contact == 1 & pitch <= -20

drop if speaker == "r" & yaw > 25
drop if speaker == "l" & yaw < -25

gen abs_yaw = abs(yaw)

twoway ///
(histogram abs_yaw if gaze_model=="Broad", ///
    percent width(2) start(0) color(navy%40) lcolor(navy)) ///
(histogram abs_yaw if gaze_model=="Direct", ///
    percent width(2) start(0) color(maroon%40) lcolor(maroon)), ///
legend(order(1 "Extended" 2 "Direct")) ///
title("Absolute Yaw Distribution by Gaze Detection Model") ///
xtitle("Absolute yaw angle (degrees)") ///
ytitle("Frequency (%)")

graph export "histyaw.png", replace width(2000)

twoway ///
(histogram abs_yaw if condition=="A", ///
    percent width(2) start(0) color(navy%40) lcolor(navy)) ///
(histogram abs_yaw if condition=="B", ///
    percent width(2) start(0) color(maroon%40) lcolor(maroon)), ///
legend(order(1 "Static Gaze Aversion" 2 "Timed Gaze Aversion")) ///
title("Absolute Yaw Distribution by Condition") ///
xtitle("Absolute yaw angle (degrees)") ///
ytitle("Frequency (%)")

graph export "histyawcond.png", replace width(2000)

restore

*SILENCE ANALYSIS
preserve

drop if missing(silence_duration)
drop if silence_duration < 0
drop if silence_duration > 10

gen in_silence = silence_duration > 0

bysort session (time_ms): gen silence_start = ///
    in_silence == 1 & in_silence[_n-1] != 1

bysort session (time_ms): gen silence_episode = sum(silence_start)

keep if in_silence == 1

collapse (max) silence_duration, ///
    by(session pair_id pair_num condition gaze_model silence_episode)

drop if silence_duration < .1
drop if silence_duration > 10

encode gaze_model, gen(gaze_model_num)
encode condition, gen(condition_num)

twoway ///
(histogram silence_duration if gaze_model=="Broad", ///
    percent width(.1) color(blue%40) lcolor(blue)) ///
(histogram silence_duration if gaze_model=="Direct", ///
    percent width(.1) color(red%40) lcolor(red)), ///
legend(order(1 "Extended gaze" 2 "Direct gaze") ///
       rows(1) position(6)) ///
title("Speaker Silence Durations by Gaze Detection Model") ///
xtitle("Silence Duration (s)") ///
ytitle("Relative Frequency (%)") ///
xscale(range(0 5)) ///
yscale(range(0 30)) ///
ylabel(0(10)30) ///
xlabel(0(.5)5) ///
graphregion(color(white)) ///
plotregion(color(white))

graph export "speaker_silence_histogram_model.png", replace width(3000)

twoway ///
(histogram silence_duration if condition=="A", ///
    percent width(.1) color(blue%40) lcolor(blue)) ///
(histogram silence_duration if condition=="B", ///
    percent width(.1) color(red%40) lcolor(red)), ///
legend(order(1 "Static Gaze Aversion" 2 "Timed Gaze Aversion") ///
       rows(1) position(6)) ///
title("Speaker Silence Durations by Robot's Gaze Behavior") ///
xtitle("Silence Duration (s)") ///
ytitle("Relative Frequency (%)") ///
xscale(range(0 5)) ///
yscale(range(0 30)) ///
ylabel(0(10)30) ///
xlabel(0(.5)5) ///
graphregion(color(white)) ///
plotregion(color(white))
graph export "speaker_silence_histogram_condition.png", replace width(3000)

* ANALYSIS SILENCE

tabstat silence_duration, ///
    by(gaze_model) ///
    stat(n mean sd median p25 p75 min max)
	
tabstat silence_duration, ///
    by(condition) ///
    stat(n mean sd median p25 p75 min max)
	
gen silence4 = silence_duration >= 4

tab silence4 gaze_model, col
tab silence4 gaze_model, row
tab silence4 condition, col
tab silence4 condition, row

mixed silence_duration ///
    i.gaze_model_num##i.condition_num ///
    || pair_num:
	
capture drop fitted_eye resid_eye re_eye tag_pair
predict fitted_eye, fitted
predict resid_eye, residuals
predict re_eye, reffects
egen tag_pair = tag(pair_num)

histogram resid_eye, normal ///

qnorm resid_eye, ///

scatter resid_eye fitted_eye, ///
    yline(0) ///

qnorm re_eye if tag_pair == 1, ///

swilk resid_eye
swilk re_eye if tag_pair == 1

* Transformation
ladder silence_duration
gen log_silence = ln(silence_duration + .01)

mixed log_silence ///
    i.gaze_model_num##i.condition_num ///
    || pair_num:

capture drop fitted_eye resid_eye re_eye tag_pair
predict fitted_eye, fitted
predict resid_eye, residuals
predict re_eye, reffects
egen tag_pair = tag(pair_num)

histogram resid_eye, normal ///

qnorm resid_eye, ///

scatter resid_eye fitted_eye, ///
    yline(0) ///

qnorm re_eye if tag_pair == 1, ///

swilk resid_eye
swilk re_eye if tag_pair == 1
histogram log_silence, normal
qnorm log_silence


regress silence_duration i.gaze_model_num

estat esize

*NON-PARAMETRIC TESTS
tempfile silence
save `silence', replace
*BETWEEN-SUBJECT EFFECT

use `silence', clear

collapse (median) median_silence = silence_duration ///
         (first) gaze_model_num, by(pair_num)

ranksum median_silence, by(gaze_model_num)

* Assumption check
tab gaze_model_num

summarize median_silence, detail

histogram median_silence if gaze_model_num == 1, ///
    normal ///
    title("Median silence: Gaze model 1")

histogram median_silence if gaze_model_num == 2, ///
    normal ///
    title("Median silence: Gaze model 2")
	
graph box median_silence, over(gaze_model_num) ///
    title("Median silence by gaze model")

twoway ///
    (kdensity median_silence if gaze_model_num == 1) ///
    (kdensity median_silence if gaze_model_num == 2), ///
    legend(label(1 "Extended") label(2 "Direct")) ///
    title("Distribution shape check: Mann-Whitney")


* WITHIN-SUBJECT EFFECT
use `silence', clear

collapse (median) median_silence = silence_duration, ///
    by(pair_num condition)

reshape wide median_silence, i(pair_num) j(condition) string

signrank median_silenceA = median_silenceB

* Assumption check
summarize median_silenceA median_silenceB

capture drop diff_silence
gen diff_silence = median_silenceB - median_silenceA

histogram diff_silence, normal ///
    title("Difference scores: Timed - Static")

graph box diff_silence, ///
    title("Boxplot of difference scores")

qnorm diff_silence, ///
    title("Q-Q plot of difference scores")

summarize diff_silence, detail

* INTERACTION EFFECT
use `silence', clear

collapse (median) median_silence = silence_duration ///
         (first) gaze_model_num gaze_model, ///
    by(pair_num condition)

reshape wide median_silence, i(pair_num) j(condition) string

gen diff_silence = median_silenceB - median_silenceA

tab gaze_model_num

* Assumption check
histogram diff_silence if gaze_model_num == 1, ///
    normal ///
    title("Difference scores: Extended gaze model")

histogram diff_silence if gaze_model_num == 2, ///
    normal ///
    title("Difference scores: Direct gaze model")

graph box diff_silence, over(gaze_model_num) ///
    title("Difference scores by gaze model")

twoway ///
    (kdensity diff_silence if gaze_model_num == 1) ///
    (kdensity diff_silence if gaze_model_num == 2), ///
    legend(label(1 "Extended") label(2 "Direct")) ///
    title("Distribution shape check: interaction")


ranksum diff_silence, by(gaze_model_num)
restore
