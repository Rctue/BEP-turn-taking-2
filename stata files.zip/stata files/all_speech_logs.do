clear
set more off

* IMPORT 

tempfile master
save `master', emptyok replace

local root "C:/Users/cascr/OneDrive/Master HTI/OneDrive - TU Eindhoven/Master/MTP/Code/Master Cas/experiment_logs"

local folders : dir "`root'" dirs "*"

foreach folder of local folders {

    if strpos("`folder'", "_") > 0 & strpos("`folder'", "__") == 0 {

        local currentfolder "`root'/`folder'"
        local speechfiles : dir "`currentfolder'" files "speech_log*.csv"

        foreach f of local speechfiles {

            di "Importing: `folder' / `f'"

            import delimited "`currentfolder'/`f'", clear

            gen session = "`folder'"
            gen speech_file = "`f'"

            append using `master'
            save `master', replace
        }
    }
}

use `master', clear

* EXTRACT PARTICIPANT ID

split session, parse("_") gen(pid)

gen left_participant  = substr(pid1, 1, length(pid1)-1)
gen right_participant = substr(pid2, 1, length(pid2)-1)

destring left_participant, gen(left_id)
destring right_participant, gen(right_id)

gen condition = upper(substr(pid1, -1, 1))

gen pair_id = string(left_id) + "_" + string(right_id)

gen gaze_model = ""
replace gaze_model = "Broad"  if left_id >= 51 & left_id <= 79
replace gaze_model = "Direct" if left_id >= 81 & left_id <= 102

drop pid1 pid2 left_participant right_participant

encode condition, gen(condition_num)
encode gaze_model, gen(gaze_model_num)
encode pair_id, gen(pair_num)

gen turn_time = offset_to_onset_interval

drop if inlist(left_id, 93, 75, 51) | ///
        inlist(right_id, 94, 76, 52)
		
gen timestamp_any = timestamp_start
replace timestamp_any = timestamp_end if missing(timestamp_any)

gen timestamp_clean = subinstr(timestamp_any, "T", " ", .)

gen double timestamp_ms = clock(timestamp_clean, "YMD hms#")
format timestamp_ms %tc

bysort session: egen dialogue_start = min(timestamp_ms)
bysort session: egen dialogue_end = max(timestamp_ms)

gen dialogue_duration_sec = (dialogue_end - dialogue_start) / 1000

* EQUAL SPEAKING MOMENTS

preserve

keep if event_type == "human_turn"
keep if turn_from == "robot"
drop if turn_time > 30

* remove overlap events
drop if interruption_type == "human_human_overlap"
drop if interruption_type == "robot_interrupts_human"
drop if interruption_type == "robot_interrupts_overlap"
* gaze cleaning
drop if time_since_gaze_start < .50

* remove very short speech
drop if missing(speaking_time)
drop if speaking_time < .50
tab speaker
tab left_id
tab right_id


restore

*Descriptive
preserve
* gaze cleaning
drop if time_since_gaze_start < .50

* remove very short speech
drop if missing(speaking_time)
drop if speaking_time < .50
collapse ///
(max) dialogue_duration_sec = dialogue_duration_sec, ///
by(session pair_id condition gaze_model left_id right_id)

gen dialogue_duration_min = dialogue_duration_sec / 60

describe
summarize

tab condition
tab gaze_model

* Overall duration descriptives across all sessions
summarize dialogue_duration_sec, detail
summarize dialogue_duration_min, detail

tabstat dialogue_duration_sec dialogue_duration_min, ///
statistics(n mean sd min max) ///
columns(statistics)

save "speech_descriptives_sessionlevel_clean.dta", replace
restore

* TURN-TAKING TIME CLEANING
preserve

keep if is_turn_take == 1

drop if missing(turn_time)
drop if turn_time > 30

gen turn_type = ""

replace turn_type = "human_human" if ///
turn_from != "robot" & turn_to != "robot"

replace turn_type = "human_robot" if ///
turn_from != "robot" & turn_to == "robot"

replace turn_type = "robot_human" if ///
turn_from == "robot" & turn_to != "robot"

* Descriptives
tabstat turn_time, by(condition) ///
stats(mean sd median min max n)

tabstat turn_time, by(gaze_model) ///
stats(mean sd median min max n)

tabstat turn_time if turn_type == "human_robot", ///
by(condition) stats(mean sd median n)

tabstat turn_time if turn_type == "robot_human", ///
by(condition) stats(mean sd median n)

tabstat turn_time if turn_type == "human_human", ///
by(condition) stats(mean sd median n)

tabstat turn_time, by(turn_type) ///
stats(mean sd median min max n)

* Mode for bins
gen turn_time_bin = floor(turn_time)

tab turn_time_bin turn_type, col

bysort turn_type turn_time_bin: gen bin_n = _N
bysort turn_type (bin_n): list turn_type turn_time_bin bin_n if _n == _N

count if turn_type == "human_human"
local total = r(N)

count if turn_type == "human_human" & turn_time < 0.5
display r(N)/`total'

count if turn_type == "human_human" & turn_time < 0.3
display r(N)/`total'
count if turn_type == "human_human" & turn_time < 1
display r(N)/`total'

*Graphs

* Histogram by turn type
* Human-Human
histogram turn_time if turn_type == "human_human", ///
    percent ///
    xscale(range(0 30)) ///
    xlabel(0(5)30) ///
    yscale(range(0 60)) ///
    ylabel(0(10)60) ///
    title("Human-Human Turn-Take Duration") ///
    xtitle("Turn-taking duration (s)") ///
    ytitle("Relative Frequency (%)") ///
    graphregion(color(white))

graph export "C:/Users/cascr/OneDrive/Master HTI/OneDrive - TU Eindhoven/Master/MTP/analysis/human_human_duration.png", ///
    replace width(2500)

* Human-Robot
histogram turn_time if turn_type == "human_robot", ///
    percent ///
    xscale(range(0 30)) ///
    xlabel(0(5)30) ///
    yscale(range(0 60)) ///
    ylabel(0(10)60) ///
    title("Human-Robot Turn-Take Duration") ///
    xtitle("Turn-taking duration (s)") ///
    ytitle("Relative Frequency (%)") ///
    graphregion(color(white))

graph export "C:/Users/cascr/OneDrive/Master HTI/OneDrive - TU Eindhoven/Master/MTP/analysis/human_robot_duration.png", ///
    replace width(2500)

* Robot-Human
histogram turn_time if turn_type == "robot_human", ///
    percent ///
    xscale(range(0 30)) ///
    xlabel(0(5)30) ///
    yscale(range(0 60)) ///
    ylabel(0(10)60) ///
    title("Robot-Human Turn-Take Duration") ///
    xtitle("Turn-taking duration (s)") ///
    ytitle("Relative Frequency (%)") ///
    graphregion(color(white))

graph export "C:/Users/cascr/OneDrive/Master HTI/OneDrive - TU Eindhoven/Master/MTP/analysis/robot_human_duration.png", ///
    replace width(2500)
	
tab turn_type

*models
mixed turn_time i.gaze_model_num##i.condition_num || pair_num:

* ASSUMPTION CHECKS FOR MIXED MODEL
* Residuals and fitted values
predict resid, residuals
predict fitted, fitted

* 1. Histogram of model residuals
histogram resid, normal ///
    title("Histogram of Mixed Model Residuals") ///
    subtitle("Turn-taking lag model") ///
    xtitle("Residuals") ///
    ytitle("Frequency") ///
    graphregion(color(white))

graph export ///
"C:/Users/cascr/OneDrive/Master HTI/OneDrive - TU Eindhoven/Master/MTP/analysis/residual_histogram.png", ///
replace width(2500)


* 2. Normal Q-Q plot of residuals
qnorm resid, ///
    title("Normal Q-Q Plot of Model Residuals") ///
    graphregion(color(white))

graph export ///
"C:/Users/cascr/OneDrive/Master HTI/OneDrive - TU Eindhoven/Master/MTP/analysis/residual_qqplot.png", ///
replace width(2500)


* 3. Residuals versus fitted values
scatter resid fitted, ///
    yline(0, lcolor(red) lpattern(dash)) ///
    title("Residuals versus Fitted Values") ///
    xtitle("Fitted values") ///
    ytitle("Residuals") ///
    graphregion(color(white))

graph export ///
"C:/Users/cascr/OneDrive/Master HTI/OneDrive - TU Eindhoven/Master/MTP/analysis/residuals_vs_fitted.png", ///
replace width(2500)

gen turn_time_log = ln(turn_time + 2.1)
mixed turn_time_log ///
    i.gaze_model_num##i.condition_num ///
    || pair_num:

capture drop fitted_eye resid_eye re_eye tag_pair
predict fitted_eye, fitted
predict resid_eye, residuals
predict re_eye, reffects
egen tag_pair = tag(pair_num)

histogram resid_eye, normal ///

qnorm resid_eye, ///

scatter resid_eye fitted_eye, ///
    yline(0) ///

qnorm re_eye if tag_pair == 1, ///

swilk resid_eye
swilk re_eye if tag_pair == 1

*NON-PARAMETRIC TEST

* Collapse to one median per pair per condition
collapse (median) median_turn_time = turn_time, ///
    by(pair_num gaze_model_num condition_num)

* Save this pair-condition dataset
tempfile turn_paircond
save `turn_paircond', replace


*BETWEEN-SUBJECT EFFECT

use `turn_paircond', clear

* Collapse to one value per pair across both conditions
collapse (median) median_turn_overall = median_turn_time ///
         (first) gaze_model_num, ///
         by(pair_num)

* Assumption checks
tab gaze_model_num

summarize median_turn_overall, detail
bysort gaze_model_num: summarize median_turn_overall, detail

graph box median_turn_overall, over(gaze_model_num) ///
    title("Median turn-taking duration by gaze model") ///
    ytitle("Median turn-taking duration")

twoway ///
    (kdensity median_turn_overall if gaze_model_num == 1) ///
    (kdensity median_turn_overall if gaze_model_num == 2), ///
    legend(label(1 "Gaze model 1") label(2 "Gaze model 2")) ///
    title("Distribution shape check: Mann-Whitney") ///
    xtitle("Median turn-taking duration") ///
    ytitle("Density")

histogram median_turn_overall if gaze_model_num == 1, ///
    normal ///
    title("Median turn-taking duration: gaze model 1")

histogram median_turn_overall if gaze_model_num == 2, ///
    normal ///
    title("Median turn-taking duration: gaze model 2")


ranksum median_turn_overall, by(gaze_model_num)


* WITHIN-SUBJECT EFFECT

use `turn_paircond', clear

reshape wide median_turn_time, ///
    i(pair_num gaze_model_num) ///
    j(condition_num)

list pair_num gaze_model_num median_turn_time*, sepby(gaze_model_num)

drop if missing(median_turn_time1) | missing(median_turn_time2)

* Assumption checks
summarize median_turn_time1 median_turn_time2, detail

gen diff_BA = median_turn_time2 - median_turn_time1
label variable diff_BA "Condition 2 - Condition 1"

summarize diff_BA, detail

histogram diff_BA, normal ///
    title("Difference scores: condition 2 - condition 1") ///
    xtitle("Difference in median turn-taking duration")

graph box diff_BA, ///
    title("Boxplot of difference scores") ///
    ytitle("Difference in median turn-taking duration")

qnorm diff_BA, ///
    title("Q-Q plot of difference scores")

* Wilcoxon signed-rank test
signrank median_turn_time1 = median_turn_time2


*INTERACTION EFFECT

* Assumption checks 
tab gaze_model_num

bysort gaze_model_num: summarize diff_BA, detail

graph box diff_BA, over(gaze_model_num) ///
    title("Difference scores by gaze model") ///
    ytitle("Condition 2 - Condition 1")

twoway ///
    (kdensity diff_BA if gaze_model_num == 1) ///
    (kdensity diff_BA if gaze_model_num == 2), ///
    legend(label(1 "Gaze model 1") label(2 "Gaze model 2")) ///
    title("Distribution shape check: interaction") ///
    xtitle("Difference score") ///
    ytitle("Density")

histogram diff_BA if gaze_model_num == 1, ///
    normal ///
    title("Difference scores: gaze model 1")

histogram diff_BA if gaze_model_num == 2, ///
    normal ///
    title("Difference scores: gaze model 2")

ranksum diff_BA, by(gaze_model_num)

restore

* EYE CONTACT TRIGGER ANALYSIS

preserve

gen eye_contact_trigger = .

replace eye_contact_trigger = 1 if ///
strpos(trigger_source, "auto_test_d") > 0

replace eye_contact_trigger = 0 if ///
strpos(trigger_source, "auto_test_e") > 0

keep if !missing(eye_contact_trigger)
drop if missing(actual_trigger_silence)

* SILENCE FIGURES

histogram actual_trigger_silence, ///
percent ///
title("Silence Before Robot Turn") ///
xtitle("Silence Duration (s)") ///
ytitle("Relative Frequency (%)")

summarize actual_trigger_silence, detail

mixed actual_trigger_silence ///
    i.eye_contact_trigger##i.gaze_model_num ///
    || pair_num:
	
capture drop fitted_eye resid_eye re_eye tag_pair
predict fitted_eye, fitted
predict resid_eye, residuals
predict re_eye, reffects
egen tag_pair = tag(pair_num)

histogram resid_eye, normal ///

qnorm resid_eye, ///

scatter resid_eye fitted_eye, ///
    yline(0) ///

qnorm re_eye if tag_pair == 1, ///

swilk resid_eye
swilk re_eye if tag_pair == 1

restore

*SUCCESSFUL TRIGGERS

preserve

gen eye_contact_trigger = .

replace eye_contact_trigger = 1 if ///
strpos(trigger_source, "auto_test_d") > 0

replace eye_contact_trigger = 0 if ///
strpos(trigger_source, "auto_test_e") > 0

keep if !missing(eye_contact_trigger)
drop if missing(actual_trigger_silence)

* overlap cleaning
drop if interruption_type != ""

* silence cleaning
tab actual_trigger_silence
drop if actual_trigger_silence < 0
drop if actual_trigger_silence > 10

* gaze cleaning
drop if time_since_gaze_start < .50

gen successful_trigger = .

replace successful_trigger = 1 if ///
actual_trigger_silence >= 0.9 & ///
actual_trigger_silence <= 1.75

replace successful_trigger = 0 if ///
actual_trigger_silence < 0.9 | ///
actual_trigger_silence > 1.75

tab successful_trigger
tab condition successful_trigger, row
tab gaze_model successful_trigger, row
gen group = gaze_model + condition
tab group successful_trigger, row

tab pair_num

melogit successful_trigger ///
    i.gaze_model_num##i.condition_num ///
    || pair_num:

estat icc
margins gaze_model_num#condition_num
marginsplot
restore

*Graphs
preserve

gen realsilence = actual_trigger_silence
keep if !missing(realsilence)
tab realsilence
sort realsilence
list session realsilence if realsilence > 4

sort gaze_model condition
by gaze_model condition: gen measurement = _n
gen threshold = 1

twoway ///
    (scatter realsilence measurement if gaze_model == "Broad" & condition == "A", ///
        mcolor(blue) msize(vsmall)) ///
    (scatter realsilence measurement if gaze_model == "Broad" & condition == "B", ///
        mcolor(green) msize(vsmall)) ///
    (scatter realsilence measurement if gaze_model == "Direct" & condition == "A", ///
        mcolor(red) msize(vsmall)) ///
    (scatter realsilence measurement if gaze_model == "Direct" & condition == "B", ///
        mcolor(yellow) msize(vsmall)) ///
    (line threshold measurement if _n == 1, ///
        lcolor(black) lpattern(shortdash) lwidth(thin)) ///
    , ///
    yline(1, lcolor(black) lpattern(shortdash) lwidth(thin)) ///
    ylabel(0(1)6) ///
    title("Actual silence before robot turn") ///
    xtitle("Turn take measurements within condition") ///
    ytitle("Actual silence (s)") ///
    legend(order(1 "Broad-A" ///
                 2 "Broad-B" ///
                 3 "Direct-A" ///
                 4 "Direct-B" ///
                 5 "Original threshold") ///
           cols(1) ///
           size(small) ///
           position(3) ///
           ring(1) ///
           region(lstyle(none))) ///
    graphregion(color(white)) ///
    plotregion(color(white))
	
graph export "RTD_trigger_silence_grouped_measurements.png", replace width(2000)

* Broad - A
histogram realsilence if gaze_model=="Broad" & condition=="A", ///
    percent ///
    width(.25) ///
	color(blue%40) ///
    start(0) ///
    xline(1, lpattern(dash) lcolor(red)) ///
    title("Extended - Static Gaze Aversion") ///
    xtitle("Silence duration before robot turn (s)") ///
    ytitle("Percentage of observations (%)") ///
	xlabel(0(1)5) ///
	xscale(range(0 5)) ///
	ylabel(0(10)60) ///
	yscale(range(0 60)) ///
    graphregion(color(white)) ///
    plotregion(color(white)) ///
    name(h1, replace)

* Broad - B
histogram realsilence if gaze_model=="Broad" & condition=="B", ///
    percent ///
    width(.25) ///
	color(red%40) ///
    start(0) ///
    xline(1, lpattern(dash) lcolor(red)) ///
    title("Extended - Timed Gaze Aversion") ///
    xtitle("Silence duration before robot turn (s)") ///
    ytitle("Percentage of observations (%)") ///
	xlabel(0(1)5) ///
	xscale(range(0 5)) ///
	ylabel(0(10)60) ///
	yscale(range(0 60)) ///
    graphregion(color(white)) ///
    plotregion(color(white)) ///
    name(h2, replace)

* Direct - A
histogram realsilence if gaze_model=="Direct" & condition=="A", ///
    percent ///
    width(.25) ///
	color(orange%40) ///
    start(0) ///
    xline(1, lpattern(dash) lcolor(red)) ///
    title("Direct - Static Gaze Aversion") ///
    xtitle("Silence duration before robot turn (s)") ///
    ytitle("Percentage of observations (%)") ///
	xlabel(0(1)5) ///
	xscale(range(0 5)) ///
	ylabel(0(10)60) ///
	yscale(range(0 60)) ///
    graphregion(color(white)) ///
    plotregion(color(white)) ///
    name(h3, replace)

* Direct - B
histogram realsilence if gaze_model=="Direct" & condition=="B", ///
    percent ///
    width(.25) ///
	color(green%40) ///
    start(0) ///
    xline(1, lpattern(dash) lcolor(red)) ///
    title("Direct - Timed Gaze Aversion") ///
    xtitle("Silence duration before robot turn (s)") ///
    ytitle("Percentage of observations (%)") ///
	xlabel(0(1)5) ///
	xscale(range(0 5)) ///
	ylabel(0(10)60) ///
	yscale(range(0 60)) ///
    graphregion(color(white)) ///
    plotregion(color(white)) ///
    name(h4, replace)

* Combine
graph combine h1 h2 h3 h4, ///
    cols(2) ///
    title("Distribution of Silence Durations Before Robot Turn") ///

graph export "histograms_conditions_silence.png", replace width(2500)

restore

preserve

* Only human turns
keep if event_type == "human_turn"

* Create variable
gen speaking_duration = speaking_time

* Clean
drop if missing(speaking_duration)
drop if speaking_duration < .5

* Create bins
gen bin = floor(speaking_duration / .5) * .5
gen one = 1

collapse (count) n=one, by(condition bin)

bysort condition: egen total = total(n)

gen percent = (n / total) * 100

gen percent_plot = percent
replace percent_plot = -percent if condition == "A"

twoway ///
    (bar percent_plot bin if condition == "A", ///
        horizontal barwidth(.4) color(blue%50)) ///
    (bar percent_plot bin if condition == "B", ///
        horizontal barwidth(.4) color(red%50)) ///
    , ///
    xline(0, lcolor(black)) ///
    xlabel(-10 "10" -5 "5" 0 "0" ///
            5 "5" 10 "10") ///
    ylabel(0(5)50) ///
    ytitle("Speaking duration (s)") ///
    xtitle("Relative Frequency (%)") ///
    title("Speaking Time Distribution by Robot's Gaze Behavior") ///
    text(25 -3 "Static gaze aversion") ///
    text(25 3 "Timed gaze aversion") ///
    legend(off) ///
    graphregion(color(white)) ///
    plotregion(color(white))

graph export ///
"C:/Users/cascr/OneDrive/Master HTI/OneDrive - TU Eindhoven/Master/MTP/analysis/mirrored_speaking_time_condition.png", ///
replace width(3000)
restore

preserve

keep if event_type == "human_turn"

gen speaking_duration = speaking_time

drop if missing(speaking_duration)
drop if speaking_duration < .5
drop if speaking_duration > 50

gen bin = floor(speaking_duration / .5) * .5
gen one = 1

collapse (count) n=one, by(gaze_model bin)

bysort gaze_model: egen total = total(n)

gen percent = (n / total) * 100
gen percent_plot = percent
replace percent_plot = -percent if gaze_model == "Broad"

twoway ///
    (bar percent_plot bin if gaze_model == "Broad", ///
        horizontal barwidth(.4) color(blue%50)) ///
    (bar percent_plot bin if gaze_model == "Direct", ///
        horizontal barwidth(.4) color(red%50)) ///
    , ///
    xline(0, lcolor(black)) ///
    xlabel(-10 "10" -5 "5" 0 "0" ///
            5 "5" 10 "10") ///
    ylabel(0(5)50) ///
    ytitle("Speaking duration (s)") ///
    xtitle("Relative Frequency (%)") ///
    title("Speaking Time Distribution by Gaze Detection Model") ///
    text(25 -3 "Extended gaze") ///
    text(25 3 "Direct gaze") ///
    legend(off) ///
    graphregion(color(white)) ///
    plotregion(color(white))

graph export ///
"C:/Users/cascr/OneDrive/Master HTI/OneDrive - TU Eindhoven/Master/MTP/analysis/mirrored_speaking_time_gaze_model.png", ///
replace width(3000)
restore

preserve

keep if event_type == "human_turn"

gen speaking_duration = speaking_time

drop if missing(speaking_duration)
drop if speaking_duration < .5
drop if speaking_duration > 50

* DESCRIPTIVES
tabstat speaking_duration, ///
    by(gaze_model) ///
    stat(n mean sd median min max)

tabstat speaking_duration, ///
    by(condition) ///
    stat(n mean sd median min max)

* ASSUMPTION CHECKS
histogram speaking_duration, normal percent
qnorm speaking_duration
sum speaking_duration, detail

* MODEL
capture drop gaze_model_num
capture drop condition_num

encode gaze_model, gen(gaze_model_num)
encode condition, gen(condition_num)

mixed speaking_duration ///
    i.gaze_model_num##i.condition_num ///
    || pair_num:
	
capture drop fitted_eye resid_eye re_eye tag_pair
predict fitted_eye, fitted
predict resid_eye, residuals
predict re_eye, reffects
egen tag_pair = tag(pair_num)

histogram resid_eye, normal ///

qnorm resid_eye, ///

scatter resid_eye fitted_eye, ///
    yline(0) ///

qnorm re_eye if tag_pair == 1, ///

swilk resid_eye
swilk re_eye if tag_pair == 1

gen log_speaking = ln(speaking_duration)

mixed log_speaking ///
    i.gaze_model_num##i.condition_num ///
    || pair_num:
	
capture drop fitted_eye resid_eye re_eye tag_pair
predict fitted_eye, fitted
predict resid_eye, residuals
predict re_eye, reffects
egen tag_pair = tag(pair_num)

histogram resid_eye, normal ///

qnorm resid_eye, ///

scatter resid_eye fitted_eye, ///
    yline(0) ///

qnorm re_eye if tag_pair == 1, ///

swilk resid_eye
swilk re_eye if tag_pair == 1

restore

*CUTINS
preserve

* keep only overlap / interruption events
keep if interruption_type != ""

* remove robot-overlap interruptions
drop if interruption_type == "robot_interrupts_overlap"

* remove invalid robot-human interruptions
drop if interruption_type == "robot_interrupts_human" ///
    & speaker == "robot" ///
    & turn_from == "robot"

gen overlap_left  = 0
gen overlap_right = 0
gen overlap_robot = 0

* human-human overlap: interrupter is the one who enters second
replace overlap_right = 1 if interruption_type == "human_human_overlap" & turn_from == "l"
replace overlap_left  = 1 if interruption_type == "human_human_overlap" & turn_from == "r"

* if speaker == "b" is used instead of interruption_type
replace overlap_right = 1 if speaker == "b" & turn_from == "l"
replace overlap_left  = 1 if speaker == "b" & turn_from == "r"

* robot interrupts human
replace overlap_robot = 1 if interruption_type == "robot_interrupts_human"

replace overlap_left  = 1 if interruption_type == "human_human_overlap" & missing(turn_from) & speaker == "l"
replace overlap_right = 1 if interruption_type == "human_human_overlap" & missing(turn_from) & speaker == "r"

* robot interrupts one human: robot + previous speaker
replace overlap_robot = 1 if interruption_type == "robot_interrupts_human"

replace overlap_left  = 1 if interruption_type == "robot_interrupts_human" & turn_from == "r"
replace overlap_right = 1 if interruption_type == "robot_interrupts_human" & turn_from == "l"

replace overlap_left  = 1 if interruption_type == "robot_interrupts_human" & missing(turn_from) & speaker == "r"
replace overlap_right = 1 if interruption_type == "robot_interrupts_human" & missing(turn_from) & speaker == "l"

* optional checks
tab interruption_type
tab interruption_type overlap_left
tab interruption_type overlap_right
tab interruption_type overlap_robot

* show overlap counts by combined condition
capture drop exp_group
egen exp_group = concat(gaze_model condition)

tab exp_group interruption_type, row chi2

* binary outcome: 0 = human-human overlap, 1 = robot-human interruption
gen robot_interrupt = interruption_type == "robot_interrupts_human"

tab exp_group robot_interrupt, row chi2

melogit robot_interrupt ///
    i.gaze_model_num##i.condition_num ///
    || pair_num:

estat icc

capture drop reffects tag_pair
predict reffects, reffects

egen tag_pair = tag(pair_num)

histogram reffects if tag_pair==1, normal ///

qnorm reffects if tag_pair==1, ///

regress robot_interrupt ///
    i.gaze_model_num##i.condition_num

estat vif
tab pair_num

gen human_overlap = interruption_type == "human_human_overlap"
gen robot_overlap = interruption_type == "robot_interrupts_human"

collapse ///
    (sum) human_overlap ///
    (sum) robot_overlap, ///
    by(pair_num condition gaze_model)

gen total_interruptions = human_overlap + robot_overlap

encode gaze_model, gen(gaze_model_num)
encode condition, gen(condition_num)

ladder total_interruptions
mixed total_interruptions ///
    i.gaze_model_num##i.condition_num ///
    || pair_num:

capture drop fitted_eye resid_eye re_eye tag_pair
predict fitted_eye, fitted
predict resid_eye, residuals
predict re_eye, reffects
egen tag_pair = tag(pair_num)

histogram resid_eye, normal ///

qnorm resid_eye, ///

scatter resid_eye fitted_eye, ///
    yline(0) ///

qnorm re_eye if tag_pair == 1, ///

swilk resid_eye
swilk re_eye if tag_pair == 1

gen sqrt_interruptions = sqrt(total_interruptions)

mixed sqrt_interruptions ///
    i.gaze_model_num##i.condition_num ///
    || pair_num:

capture drop fitted_eye resid_eye re_eye tag_pair
predict fitted_eye, fitted
predict resid_eye, residuals
predict re_eye, reffects
egen tag_pair = tag(pair_num)

histogram resid_eye, normal ///

qnorm resid_eye, ///

scatter resid_eye fitted_eye, ///
    yline(0) ///

qnorm re_eye if tag_pair == 1, ///

swilk resid_eye
swilk re_eye if tag_pair == 1

restore

*turn types
preserve

keep if is_turn_take == 1
drop if missing(turn_time)

* Create turn type
capture drop turn_type
gen turn_type = ""

replace turn_type = "human_human" if ///
    turn_from != "robot" & turn_to != "robot"

replace turn_type = "human_robot" if ///
    turn_from != "robot" & turn_to == "robot"

replace turn_type = "robot_human" if ///
    turn_from == "robot" & turn_to != "robot"

drop if turn_type == ""
drop if turn_time > 30
drop if time_since_gaze_start < .50

* Descriptive table
capture drop exp_group
egen exp_group = concat(gaze_model condition), punct("_")

tab turn_type
tab exp_group turn_type, chi2 row

restore

*speaker utterances mean
preserve

* Keep only human utterances
keep if event_type == "human_turn"

* Clean speaking turns
drop if missing(speaking_time)
drop if speaking_time < .5

* Count human utterances per session
gen utterance = 1

collapse ///
    (count) total_utterances = utterance ///
    (min) dialogue_start = dialogue_start ///
    (max) dialogue_end = dialogue_end, ///
    by(pair_num gaze_model condition session)

* Dialogue duration in seconds
gen dialogue_duration_sec = (dialogue_end - dialogue_start) / 1000

* Average utterances per minute
gen utterances_per_min = total_utterances / (dialogue_duration_sec / 60)

* Combined condition
capture drop exp_group
egen exp_group = concat(gaze_model condition)

* Encode factors
capture drop gaze_model_num
capture drop condition_num
encode gaze_model, gen(gaze_model_num)
encode condition, gen(condition_num)

* Descriptives
tabstat utterances_per_min, ///
    by(exp_group) ///
    stat(n mean sd median min max)

tabstat utterances_per_min, ///
    by(condition) ///
    stat(n mean sd median min max)

tabstat utterances_per_min, ///
    by(gaze_model) ///
    stat(n mean sd median min max)

* Mixed model: mixed design
mixed utterances_per_min ///
    i.gaze_model_num##i.condition_num ///
    || pair_num:

capture drop fitted_eye resid_eye re_eye tag_pair
predict fitted_eye, fitted
predict resid_eye, residuals
predict re_eye, reffects
egen tag_pair = tag(pair_num)

histogram resid_eye, normal ///

qnorm resid_eye, ///

scatter resid_eye fitted_eye, ///
    yline(0) ///

qnorm re_eye if tag_pair == 1, ///

swilk resid_eye
swilk re_eye if tag_pair == 1

* Tests
testparm i.gaze_model_num
testparm i.condition_num
testparm i.gaze_model_num#i.condition_num

ladder utterances_per_min
	
gen sqrt_upm = sqrt(utterances_per_min)

mixed sqrt_upm ///
    i.gaze_model_num##i.condition_num ///
    || pair_num:

capture drop fitted_eye resid_eye re_eye tag_pair
predict fitted_eye, fitted
predict resid_eye, residuals
predict re_eye, reffects
egen tag_pair = tag(pair_num)

histogram resid_eye, normal ///

qnorm resid_eye, ///

scatter resid_eye fitted_eye, ///
    yline(0) ///

qnorm re_eye if tag_pair == 1, ///

swilk resid_eye
swilk re_eye if tag_pair == 1
	
collapse ///
    (mean) mean_utt = utterances_per_min ///
    (semean) se_utt = utterances_per_min, ///
    by(gaze_model_num condition_num)

gen ci_low  = mean_utt - 1.96*se_utt
gen ci_high = mean_utt + 1.96*se_utt

gen x = .
replace x = 1 if gaze_model_num==1 & condition_num==1
replace x = 2 if gaze_model_num==1 & condition_num==2
replace x = 4 if gaze_model_num==2 & condition_num==1
replace x = 5 if gaze_model_num==2 & condition_num==2
gen xlab = x + 0.15

twoway ///
    (bar mean_utt x, barwidth(0.8)) ///
    (rcap ci_high ci_low x) ///
    (scatter mean_utt xlab, ///
        msymbol(none) ///
        mlabel(mean_utt) ///
        mlabformat(%4.2f) ///
		mlabcolor(black) ///
        mlabposition(12)) ///
    , ///
    xlabel(1 "Static" 2 "Timed" 4 "Static" 5 "Timed") ///
    ytitle("Utterances per minute") ///
    ylabel(0(1)5, angle(0)) ///
    yscale(range(0 5)) ///
    text(4.6 1.5 "Extended Gaze Detection", placement(c)) ///
    text(4.6 4.5 "Direct Gaze Detection", placement(c)) ///
    graphregion(color(white)) ///
    plotregion(color(white)) ///
    legend(off)

graph export ///
"C:/Users/cascr/OneDrive/Master HTI/OneDrive - TU Eindhoven/Master/MTP/analysis/utterancepermin.png", ///
replace width(3000)
restore