clear
set more off

import excel ///
"C:\Users\cascr\OneDrive\Master HTI\OneDrive - TU Eindhoven\Master\MTP\analysis\questionnaire_data\Post-Experiment Questionnaire.xlsx", ///
firstrow clear

* Inspect
describe

rename WhatisyourparticipantID id
rename Whichtaskdidyoucomplete task
rename Id orderid

replace id = "99" if id == "2090937"
replace id = "100" if id == "2246473"

rename *, lower

destring id, replace
destring competent capable strange happy aggressive ///
knowledgable responsive awkward compassionate ///
dangerous emotional interactive social reliable ///
awful organic scary seemstohavefeelings, replace

drop if inlist(id, 93, 94, 51, 52, 75, 76)

count
tab id

*Conditions
gen gaze_model = ""
replace gaze_model = "Broad"  if id >= 51 & id <= 79
replace gaze_model = "Direct" if id >= 81 & id <= 102

encode gaze_model, gen(gaze_model_num)

gen condition = ""
replace condition = "A" if task == "Designing a dream house"
replace condition = "B" if task == "Planning a holiday"

encode condition, gen(condition_num)

*Check values
tab condition
tab condition_num

tab id gaze_model, missing
tab gaze_model, missing

duplicates report id task
duplicates list id task

foreach v in competent capable strange happy aggressive ///
knowledgable responsive awkward compassionate ///
dangerous emotional interactive social reliable ///
awful organic scary seemstohavefeelings {

    tab `v', missing
    assert inrange(`v',1,5) if !missing(`v')
}

* ROSAS SUBSCALES
egen rosas_warmth = rowmean( happy compassionate emotional social organic seemstohavefeelings)

egen rosas_competence = rowmean( ///
competent capable knowledgable ///
responsive interactive reliable)

egen rosas_discomfort = rowmean( ///
strange aggressive awkward ///
dangerous awful scary)

alpha happy compassionate emotional social organic seemstohavefeelings

alpha competent capable knowledgable responsive interactive reliable

alpha strange aggressive awkward dangerous awful scary

hist rosas_warmth
hist rosas_competence
hist rosas_discomfort

sum rosas_warmth
sum rosas_competence
sum rosas_discomfort

*ROSAS WARMTH
mixed rosas_warmth ///
    i.gaze_model_num##i.condition_num ///
    || id:

capture drop resid fitted
predict resid, residuals
predict fitted, fitted
swilk resid
histogram resid, normal

qnorm resid

scatter resid fitted, ///
    yline(0)

capture drop reffects
predict reffects, reffects
qnorm reffects
	
mixed rosas_warmth ///
    i.gaze_model_num##i.condition_num ///
    || id:

estat icc
estat ic

*ROSAS COMPETENCE
mixed rosas_competence ///
    i.gaze_model_num##i.condition_num ///
    || id:

*assumption
capture drop resid fitted
predict resid, residuals
predict fitted, fitted
swilk resid
histogram resid, normal

qnorm resid

scatter resid fitted, ///
    yline(0)

capture drop reffects
predict reffects, reffects
qnorm reffects
	
mixed rosas_competence ///
    i.gaze_model_num##i.condition_num ///
    || id:

estat icc
estat ic

*ROSAS DISCOMFORT
mixed rosas_discomfort ///
    i.gaze_model_num##i.condition_num ///
    || id:
margins gaze_model_num#condition_num
pwcompare gaze_model_num#condition_num, effects mcompare(bonferroni)
capture drop resid fitted
predict resid, residuals
predict fitted, fitted
swilk resid

histogram resid, normal

qnorm resid

scatter resid fitted, ///
    yline(0)

capture drop reffects
predict reffects, reffects
qnorm reffects
alpha strange aggressive awkward dangerous awful scary, item
mixed rosas_discomfort ///
    i.gaze_model_num##i.condition_num ///
    || id:

estat icc
estat ic

* SASSI SUBSCALES
destring mistyispleasant ///
theinteractionwithmistyisfr ///
ialwaysknewwhattosayordo ///
mistyisaccurate ///
theinteractionwithmistyisre ///
mistyrespondedquickly ///
ifelttensewhileinteractingw ///
theinteractionwithmistyisef ///
mistyistooinflexible ///
iwasnotalwayssurewhatmisty ///
theinteractionwithmistyisbo ///
mistymakesfewerrors ///
ifeltconfidentusingmisty ///
theinteractionwithmistyisun ///
mistytooktoolongtorespond ///
itisclearhowtospeaktomist ///
mistyisunreliable ///
ienjoyedinteractingwithmisty ///
theinteractionwithmistyisco ///
mistyisuseful ///
ifeltcalmwhileinteractingwi ///
theinteractionwithmistyisir ///
mistydidnotalwaysdowhatiw ///
iwasabletorecovereasilyfro ///
itiseasytolosetrackofwher ///
mistyisfriendly ///
theinteractionwithmistyisfa ///
isometimeswonderedifiwasus ///
mistyiseasytouse ///
mistydidnotalwaysdowhatie ///
ahighlevelofconcentrationis ///
ialwaysknewwhattosaytomis ///
iwouldusemistyagain ///
mistyisdependable ///
mistyrespondstooslowly ///
ifeltincontroloftheinterac ///
itiseasytolearnhowtousem, replace

* Reverse negatively worded items
gen mistydidnotalwaysdowhatiw_r = 8 - mistydidnotalwaysdowhatiw
gen mistydidnotalwaysdowhatie_r = 8 - mistydidnotalwaysdowhatie
gen mistyisunreliable_r = 8 - mistyisunreliable
gen theinteractionwithmistyisun_r = 8 - theinteractionwithmistyisun

* Accuracy scale
egen sassi_accuracy = rowmean( ///
    mistyisaccurate ///
    mistymakesfewerrors ///
    mistydidnotalwaysdowhatiw_r ///
    mistydidnotalwaysdowhatie_r ///
    mistyisdependable ///
	mistyisunreliable_r ///
    theinteractionwithmistyisun_r ///
    theinteractionwithmistyisco ///
    theinteractionwithmistyisef)

* Likeability
egen sassi_likeability = rowmean( ///
mistyispleasant ///
mistyisfriendly ///
ienjoyedinteractingwithmisty ///
iwouldusemistyagain ///
mistyisuseful ///
ifeltcalmwhileinteractingwi)

* Cognitive demand
egen sassi_cognitive = rowmean( ///
ahighlevelofconcentrationis ///
ifelttensewhileinteractingw ///
iwasnotalwayssurewhatmisty ///
isometimeswonderedifiwasus ///
itiseasytolosetrackofwher)

* Annoyance
egen sassi_annoyance = rowmean( ///
theinteractionwithmistyisfr ///
theinteractionwithmistyisbo ///
theinteractionwithmistyisir ///
mistyistooinflexible ///
mistytooktoolongtorespond)

* Habitability
egen sassi_habitability = rowmean( ///
ialwaysknewwhattosayordo ///
itisclearhowtospeaktomist ///
ifeltconfidentusingmisty ///
iwasabletorecovereasilyfro ///
ialwaysknewwhattosaytomis ///
ifeltincontroloftheinterac ///
itiseasytolearnhowtousem ///
mistyiseasytouse)

* Speed
* reverse
gen mistyrespondedquickly_r = 8 - mistyrespondedquickly
gen theinteractionwithmistyisfa_r = 8 - theinteractionwithmistyisfa

egen sassi_speed = rowmean( ///
mistyrespondedquickly_r ///
theinteractionwithmistyisfa_r ///
mistytooktoolongtorespond ///
mistyrespondstooslowly)

alpha mistyisaccurate mistymakesfewerrors mistydidnotalwaysdowhatiw_r ///
mistydidnotalwaysdowhatie_r mistyisdependable mistyisunreliable_r ///
theinteractionwithmistyisun_r theinteractionwithmistyisco ///
theinteractionwithmistyisef

alpha mistyispleasant mistyisfriendly ienjoyedinteractingwithmisty ///
iwouldusemistyagain mistyisuseful ifeltcalmwhileinteractingwi

alpha ahighlevelofconcentrationis ifelttensewhileinteractingw ///
iwasnotalwayssurewhatmisty isometimeswonderedifiwasus ///
itiseasytolosetrackofwher

alpha theinteractionwithmistyisfr theinteractionwithmistyisbo ///
theinteractionwithmistyisir mistyistooinflexible mistytooktoolongtorespond

alpha ialwaysknewwhattosayordo itisclearhowtospeaktomist ///
ifeltconfidentusingmisty iwasabletorecovereasilyfro ///
ialwaysknewwhattosaytomis ifeltincontroloftheinterac ///
itiseasytolearnhowtousem mistyiseasytouse

alpha mistyrespondedquickly_r ///
theinteractionwithmistyisfa_r ///
mistytooktoolongtorespond ///
mistyrespondstooslowly

* SASSI Accuracy
mixed sassi_accuracy i.gaze_model_num##i.condition_num || id:
capture drop resid fitted
predict resid, residuals
predict fitted, fitted
swilk resid
histogram resid, normal

qnorm resid

scatter resid fitted, ///
    yline(0)

capture drop reffects
predict reffects, reffects
qnorm reffects

* SASSI Likeability
mixed sassi_likeability i.gaze_model_num##i.condition_num || id:
pwcompare gaze_model_num#condition_num, ///
    effects mcompare(bonferroni)
capture drop resid fitted
predict resid, residuals
predict fitted, fitted
swilk resid
histogram resid, normal

qnorm resid

scatter resid fitted, ///
    yline(0)
capture drop reffects
predict reffects, reffects
qnorm reffects

* SASSI Cognitive Demand
mixed sassi_cognitive i.gaze_model_num##i.condition_num || id:
capture drop resid fitted
predict resid, residuals
predict fitted, fitted
swilk resid
histogram resid, normal

qnorm resid

scatter resid fitted, ///
    yline(0)

capture drop reffects
predict reffects, reffects
qnorm reffects

* SASSI Annoyance
mixed sassi_annoyance i.gaze_model_num##i.condition_num || id:
capture drop resid fitted
predict resid, residuals
predict fitted, fitted

histogram resid, normal
swilk resid
qnorm resid

scatter resid fitted, ///
    yline(0)
capture drop reffects
predict reffects, reffects
qnorm reffects
* SASSI Habitability
mixed sassi_habitability i.gaze_model_num##i.condition_num || id:
pwcompare gaze_model_num#condition_num, effects mcompare(bonferroni)
capture drop resid fitted
predict resid, residuals
predict fitted, fitted

histogram resid, normal
swilk resid
qnorm resid

scatter resid fitted, ///
    yline(0)
capture drop reffects
predict reffects, reffects
qnorm reffects

* SASSI Speed
mixed sassi_speed i.gaze_model_num##i.condition_num || id:
capture drop resid fitted
predict resid, residuals
predict fitted, fitted
swilk resid

histogram resid, normal

qnorm resid

scatter resid fitted, ///
    yline(0)

capture drop reffects
predict reffects, reffects
qnorm reffects

* FIGURES
preserve

collapse (mean) mean_like=sassi_likeability ///
         (sd) sd_like=sassi_likeability ///
         (count) n=sassi_likeability, ///
         by(gaze_model condition)

gen like = sd_like / sqrt(n)
gen ci_low = mean_like - 1.96 * like
gen ci_high = mean_like + 1.96 * like

gen x = .
replace x = 1 if gaze_model == "Broad"  & condition == "A"
replace x = 2 if gaze_model == "Broad"  & condition == "B"
replace x = 4 if gaze_model == "Direct" & condition == "A"
replace x = 5 if gaze_model == "Direct" & condition == "B"
gen xlab = x + 0.15

twoway ///
    (bar mean_like x if condition == "A", ///
        barwidth(.8) color(navy%70)) ///
    (bar mean_like x if condition == "B", ///
        barwidth(.8) color(green%70)) ///
    (rcap ci_low ci_high x, ///
        lcolor(black)) ///
    (scatter mean_like xlab, ///
		msymbol(none) ///
		mlabel(mean_like) ///
		mlabcolor(black) ///
		mlabformat(%3.2f) ///
		mlabposition(12) ///
		mlabsize(medium)), ///
    xlabel(1.5 "Extended" 4.5 "Direct") ///
    ylabel(, angle(horizontal)) ///
    ytitle("Mean SASSI Likeability") ///
    xtitle("Gaze detection model") ///
    legend(order(1 "Static Gaze Aversion" 2 "Timed Gaze Aversion") ///
           position(6) rows(1)) ///
    graphregion(color(white)) ///
    plotregion(color(white))

graph export "sassi_likeability_bar.png", replace width(2000)

restore

*Interaction analyses
merge m:1 id using ///
"C:\Users\cascr\OneDrive\Master HTI\OneDrive - TU Eindhoven\Master\MTP\analysis\questionnaire_data\pre_demographics_clean.dta"

tab _merge
describe age gender height_new ///
experience_robots_binary ///
experience_interface_binary

misstable summarize age gender ///
height_new ///
experience_robots_binary ///
experience_interface_binary

mixed sassi_likeability ///
    i.gaze_model_num##i.condition_num ///
    c.age ///
    c.age#i.condition_num ///
    || id:

encode gender, gen(gender_num)
tab gender
mixed sassi_likeability ///
    i.gaze_model_num##i.condition_num ///
    i.gender_num ///
    i.gender_num#i.condition_num ///
    || id:

mixed sassi_likeability ///
    i.gaze_model_num##i.condition_num ///
    i.experience_robots_binary ///
    i.experience_robots_binary#i.condition_num ///
    || id:

mixed sassi_likeability ///
    i.gaze_model_num##i.condition_num ///
    i.experience_interface_binary ///
    i.experience_interface_binary#i.condition_num ///
    || id: